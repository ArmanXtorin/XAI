# ArmanAI Mobile v0.1
Native Android Kotlin app. Offline chat, commands, persistent history and key/value memory.

## Build without a PC
1. Create a **private** GitHub repository named `ArmanAI-Mobile`.
2. Upload the *contents* of this folder to the repository, preserving paths (the hidden `.github` folder is essential). GitHub mobile browser desktop mode or a phone Git client may help. Alternatively upload this project to a browser-based development environment with git access.
3. Open **Actions > Build Android APK > Run workflow**. A push to main also triggers a build.
4. After the job succeeds, open its run, download artifact `ArmanAI-Mobile-debug-apk`, extract the ZIP and install `app-debug.apk` on your phone.

Note: This is a debug APK for personal testing, not a Play Store release. Android may ask you to allow installation from the app you used to open the APK. Only install APKs you built and trust.

## Commands
`help`, `time`, `date`, `remember favorite_game = Minecraft`, `recall favorite_game`, `memories`, `clear memory favorite_game`.

No INTERNET permission, no remote AI, no background monitoring. All saved data remains on device. No build was run in the packaging environment; GitHub Actions is the compile/test step.
